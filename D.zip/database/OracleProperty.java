package vn.com.ocb.omni.cib.config.database;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import vn.com.ocb.omni.cib.config.YamlPropertySourceFactory;

@Configuration
@ConfigurationProperties(prefix = "oracle")
@PropertySource(value = "classpath:database-config.yml", factory = YamlPropertySourceFactory.class)
@NoArgsConstructor
@Setter
@Getter
public class OracleProperty {

    private String url;
    private String username;
    private String password;
    private String driverClassName;
    private String dialect;
    private String ddlAuto;
    private String physicalStrategy;

}
