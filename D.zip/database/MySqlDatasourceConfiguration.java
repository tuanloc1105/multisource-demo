package vn.com.ocb.omni.cib.config.database;

import lombok.extern.slf4j.Slf4j;
import org.hibernate.cfg.AvailableSettings;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;

@Configuration
@Slf4j
@EnableJpaRepositories(
        basePackages = {
                "vn.com.ocb.omni.cib.repository.device",
                "vn.com.ocb.omni.cib.repository.notification",
                "vn.com.ocb.omni.cib.repository.singlestore"
        },
        entityManagerFactoryRef = "mysqlEntityManager",
        transactionManagerRef = "mysqlTransactionManager"
)
public class MySqlDatasourceConfiguration {

    private final MySqlProperty property;

    public MySqlDatasourceConfiguration(@Qualifier("mySqlProperty") MySqlProperty property) {
        this.property = property;
    }

    @Bean("mysqlDatasource")
    public DataSource mysqlDatasource() {
        log.info("Generating Mysql datasource");
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(property.getDriverClassName());
        dataSource.setUrl(property.getUrl());
        dataSource.setUsername(property.getUsername());
        dataSource.setPassword(property.getPassword());

        return dataSource;
    }

    @Bean("mysqlEntityManager")
    public LocalContainerEntityManagerFactoryBean mysqlEntityManager(@Qualifier("mysqlDatasource") DataSource mysqlDatasource) {
        log.info("Generating MySql entity manager");
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(mysqlDatasource);

        // Scan Entities in Package:
        em.setPackagesToScan(
                "vn.com.ocb.omni.cib.entity.device",
                "vn.com.ocb.omni.cib.entity.notification",
                "vn.com.ocb.omni.cib.repository.singlestore.entities"
        );
        em.setPersistenceUnitName("PERSISTENCE_UNIT_NAME_MYSQL");

        //
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();

        em.setJpaVendorAdapter(vendorAdapter);

        HashMap<String, Object> properties = new HashMap<>();

        // JPA & Hibernate
        properties.put(AvailableSettings.DIALECT, property.getDialect());
        properties.put(AvailableSettings.HBM2DDL_AUTO, property.getDdlAuto());
        properties.put(AvailableSettings.PHYSICAL_NAMING_STRATEGY, property.getPhysicalStrategy());

        em.setJpaPropertyMap(properties);
        em.afterPropertiesSet();
        return em;
    }

    @Bean("mysqlTransactionManager")
    public PlatformTransactionManager mysqlTransactionManager(@Qualifier("mysqlEntityManager") LocalContainerEntityManagerFactoryBean mysqlEntityManager) {
        log.info("Generating MySql Jpa transaction manager");
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(mysqlEntityManager.getObject());
        transactionManager.setJpaPropertyMap(mysqlEntityManager.getJpaPropertyMap());
        return transactionManager;
    }

}
